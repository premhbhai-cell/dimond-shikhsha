/* Shared folder-based image sliders for all Diamond Shiksha pages.
   Add image files to assets/sliders/slider1 or slider2, then run generate-slider-manifest.py. */
(() => {
  const assetBase = new URL('../sliders/', document.currentScript.src);
  const candidates = document.querySelectorAll('.elementor-top-section, main > section, body > section, section.rf-section, section.rf-gallery-section, section.rf-page-hero');
  const sections = [...new Set([...candidates])].filter(el =>
    !el.closest('header, footer') &&
    !el.classList.contains('rf-page-hero') &&
    !el.hasAttribute('data-ds-slider')
  );
  if (sections.length < 2) return;

  function makeSlider(number, images) {
    if (!images.length) return null;
    const slider = document.createElement('section');
    slider.className = 'ds-auto-slider';
    slider.setAttribute('aria-label', `Image gallery ${number}`);
    slider.innerHTML = `<div class="ds-auto-slider__track"></div>
      <button class="ds-auto-slider__btn ds-auto-slider__btn--prev" aria-label="Previous image" type="button">‹</button>
      <button class="ds-auto-slider__btn ds-auto-slider__btn--next" aria-label="Next image" type="button">›</button>
      <div class="ds-auto-slider__dots"></div>`;
    const track = slider.querySelector('.ds-auto-slider__track');
    const dots = slider.querySelector('.ds-auto-slider__dots');
    images.forEach((filename, index) => {
      const slide = document.createElement('div');
      slide.className = 'ds-auto-slider__slide';
      const img = document.createElement('img');
      img.src = new URL(`slider${number}/${encodeURIComponent(filename)}`, assetBase).href;
      img.alt = `Diamond Shiksha gallery image ${index + 1}`;
      img.loading = index === 0 ? 'eager' : 'lazy';
      slide.appendChild(img); track.appendChild(slide);
      const dot = document.createElement('button');
      dot.className = 'ds-auto-slider__dot'; dot.type = 'button';
      dot.setAttribute('aria-label', `Show image ${index + 1}`);
      dot.addEventListener('click', () => go(index));
      dots.appendChild(dot);
    });
    let current = 0;
    const dotItems = [...dots.children];
    function go(index) {
      current = (index + images.length) % images.length;
      track.style.transform = `translateX(-${current * 100}%)`;
      dotItems.forEach((d, i) => d.setAttribute('aria-current', String(i === current)));
    }
    slider.querySelector('.ds-auto-slider__btn--prev').addEventListener('click', () => go(current - 1));
    slider.querySelector('.ds-auto-slider__btn--next').addEventListener('click', () => go(current + 1));
    go(0);
    if (images.length > 1) {
      let timer = setInterval(() => go(current + 1), 4000);
      slider.addEventListener('mouseenter', () => clearInterval(timer));
      slider.addEventListener('mouseleave', () => { clearInterval(timer); timer = setInterval(() => go(current + 1), 4000); });
    } else {
      slider.querySelectorAll('button').forEach(b => b.hidden = true);
    }
    return slider;
  }

  async function init() {
    const allImages = await Promise.all([1, 2].map(async n => {
      try {
        const response = await fetch(new URL(`slider${n}/images.json`, assetBase));
        if (!response.ok) return [];
        const data = await response.json();
        return Array.isArray(data) ? data.filter(x => typeof x === 'string') : [];
      } catch { return []; }
    }));
    // Place each slider between content sections, never together beneath the hero.
    const placements = [
      { number: 1, after: Math.min(1, sections.length - 1) },
      { number: 2, after: Math.min(3, sections.length - 1) }
    ];
    placements.forEach(({number, after}) => {
      const slider = makeSlider(number, allImages[number - 1]);
      const target = sections[after];
      if (slider && target && target.parentNode) {
        target.insertAdjacentElement('afterend', slider);
      }
    });
  }
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', init, {once:true});
  else init();
})();
