Put your images for slider2 here (.jpg, .jpeg, .png, .webp, .gif). Run generate-slider-manifest.py before deploying to update images.json.
