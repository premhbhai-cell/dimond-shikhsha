#!/usr/bin/env python3
"""Generate image manifests for Diamond Shiksha website sliders before deployment."""
from pathlib import Path
import json
ROOT = Path(__file__).resolve().parent
EXTS = {".jpg", ".jpeg", ".png", ".webp", ".gif", ".avif"}
for name in ("slider1", "slider2"):
    folder = ROOT / "assets" / "sliders" / name
    folder.mkdir(parents=True, exist_ok=True)
    images = sorted(p.name for p in folder.iterdir() if p.is_file() and p.suffix.lower() in EXTS)
    (folder / "images.json").write_text(json.dumps(images, indent=2), encoding="utf-8")
    print(f"{name}: {len(images)} images")
