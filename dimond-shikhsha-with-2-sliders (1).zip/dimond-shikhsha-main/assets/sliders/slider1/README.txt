Put your images for slider1 here (.jpg, .jpeg, .png, .webp, .gif). Run generate-slider-manifest.py before deploying to update images.json.
